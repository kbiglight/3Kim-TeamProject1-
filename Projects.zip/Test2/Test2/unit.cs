﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
    class unit
    {
        int x=new int();
        int pow = new int();
        int hp = new int();
        int motion = new int();
        int live = new int();
        int liven = new int();
        int range = new int();
        public unit() { 

           
        }
        public void init() {
            x = 20;
            pow = 1;
            hp = 5;
            motion = 0;
            live = 0;
            liven = 0;
            range = 10;
        }
        public int X() { return x; }
        public void move() { x = x + 1; }
        void hit(int l) { hp = hp - l; }
        public int attack() { return pow; }
        public int LL() { return live; }
        public int search() { return range; }//20,200
        public void sumon() { liven = 1;live = 1; }
    }
}

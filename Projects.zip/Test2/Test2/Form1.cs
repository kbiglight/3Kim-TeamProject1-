﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test2
{
    public partial class Form1 : Form
    {
        Image dblbuff; // 이미지를 그릴 백버퍼
        Graphics g; // 
        Graphics L;
        int count;
        unit[] tester;
        public Form1()
        {
            InitializeComponent();
            dblbuff = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(dblbuff);
            L = Graphics.FromImage(dblbuff);
            InitializeComponent();
            count = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (count > 20)
            {
            }
            else {
                tester[count].sumon();
                count++;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            L = pictureBox1.CreateGraphics();
            for(int K = 0; K <= count; K++)
            {
                int FF=tester[K].LL();
                string SUM = string.Format("{0} {1} {2}", FF,K,K);
                MessageBox.Show("{0}", SUM);
                if (FF == 1)
                {
                    tester[K].move();
                    L.DrawImage(Test2.Properties.Resources.클리어, tester[K].X(), 220);
                }
            }
            //L.DrawImage(Test.Properties.Resources.공감, 0, 0);
           // L.DrawImage(Test2.Properties.Resources.임시유닛, k, 0);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int L = 0;
            count = 0;
            tester = new unit[20];
            for (int G = 0; G < 20; G++)
            {
                tester[G] = new unit();
                tester[G].init();

            }
            L++;
            if (L>0) { timer2.Enabled = false; }
        }
    }
}

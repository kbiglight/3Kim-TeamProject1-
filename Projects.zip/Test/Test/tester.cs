﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Test 
{
    class tester : Form1
{
        public PictureBox K = new PictureBox();
        public int i=0;
        public void KKK()
        {
            if (i < 1)
            {
                K.SetBounds(0, 0, 200, 200);
                K.Image = Test.Properties.Resources.공감;
                Controls.Add(K);
                i++;
                
            }
        } 
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test
{
    public partial class Form1 : Form
    {
        Image dblbuff; // 이미지를 그릴 백버퍼
        Graphics g; // 
        Graphics L;
        public Form1()
        {
            InitializeComponent();

            dblbuff = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(dblbuff);
            L = Graphics.FromImage(dblbuff);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
          
            
        }
        public int k = 0;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            g.DrawImage(Test.Properties.Resources.공감, 0, 0, 300, 450);
            
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(dblbuff,0,0);
            L = e.Graphics;
            L.DrawImage(Test.Properties.Resources.공감, 0, 0);

        }
        private void button1_Click(object sender, EventArgs e)
        {   L = pictureBox1.CreateGraphics();
            L.DrawImage(Test.Properties.Resources.공감, 0, 0);
            L.DrawImage(Test.Properties.Resources.임시유닛,0,0);
            KPK();
        }
        void KPK() {
            tester KPP = new tester();
            KPP.KKK();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Test.Properties.Resources.공감;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            L = pictureBox1.CreateGraphics();
            //L.DrawImage(Test.Properties.Resources.공감, 0, 0);
            L.DrawImage(Test.Properties.Resources.임시유닛, k, 0);
            k++;
        }
    }
}

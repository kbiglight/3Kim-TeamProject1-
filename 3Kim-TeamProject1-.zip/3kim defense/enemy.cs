﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//적입니다.
//적은 이동방향과 표적,유닌소환만 다를 뿐 기본적으로 유닛과 같습니다.
//소환방법은 일반적으로는 특정 패턴을, 난이도가 높아질수록 우리가 유닛을 뽑는 것을 참조하여 뽑습니다.
namespace _3kim_defense
{
    class enemy
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3kim_defense
{
    class Tower//적 타워, 아군 타워의 좌표 등
    {//아군(26,222),적(483,222)
        public void towerset() {

        }
    }
}

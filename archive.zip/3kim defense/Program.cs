﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//해야 할 과제
//유닛 클래스
//인터페이스 생성
//데이터베이스
//아직은 클릭으로 진행되지만 차차 키보드로도 사용 가능하게 하기
namespace _3kim_defense
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.Run(new Form1());
        }
    }

}

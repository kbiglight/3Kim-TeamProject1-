﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3kim_defense
{
    class Unit_Database//유닛의 정보를 저장하는 데이터베이스에서 능력치를 불러오는 함수입니다.
    {
        int[] SumonUnit = new int[20];
    }
}
